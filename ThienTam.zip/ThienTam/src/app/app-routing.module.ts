import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrangChuComponent } from './components/trang-chu/trang-chu.component';
import { GioiThieuComponent } from './components/gioi-thieu/gioi-thieu.component';
import { DichVuBangGiaComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia/dich-vu-bang-gia.component';
import { TinTucComponent } from './components/tin-tuc-page/tin-tuc/tin-tuc.component';
import { LienHeComponent } from './components/lien-he/lien-he.component';
import { TinTucContentComponent } from './components/tin-tuc-page/tin-tuc-content/tin-tuc-content.component';
import { TinTucPageComponent } from './components/tin-tuc-page/tin-tuc-page/tin-tuc-page.component';
import { DichVuBangGiaPageComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia-page/dich-vu-bang-gia-page.component';
import { DichVuBangGiaContentSignupComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia-content-signup/dich-vu-bang-gia-content-signup.component';

const routes: Routes = [
  
  //Home-page
  {
    path: '',
    redirectTo: "thientam.com.vn",
    pathMatch: 'full',
  },
  {
    path: 'thientam.com.vn',
    component: TrangChuComponent
  },
  {
    path: 'thientam.com.vn/gioithieu',
    component: GioiThieuComponent
  },
  {
    path: 'thientam.com.vn/dichvu_banggia',
    component: DichVuBangGiaPageComponent,
    children: [
      {
        path:'',
        component: DichVuBangGiaComponent
      },
      {
        path:'dang_ky_dich_vu',
        component: DichVuBangGiaContentSignupComponent
      }
    ]
  },
  {
    path: 'thientam.com.vn/tintuc',
    component: TinTucPageComponent,
    children: [
      {
        path: '',
        component: TinTucComponent,
      },
      {
        path: 'noidung_tintuc',
        component: TinTucContentComponent,
      }
    ]
  },
  {
    path: 'thientam.com.vn/lienhe',
    component: LienHeComponent
  },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
