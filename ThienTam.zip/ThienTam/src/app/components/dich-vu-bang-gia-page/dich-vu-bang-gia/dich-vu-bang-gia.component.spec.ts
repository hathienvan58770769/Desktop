import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DichVuBangGiaComponent } from './dich-vu-bang-gia.component';

describe('DichVuBangGiaComponent', () => {
  let component: DichVuBangGiaComponent;
  let fixture: ComponentFixture<DichVuBangGiaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DichVuBangGiaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DichVuBangGiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
