import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dich-vu-bang-gia',
  templateUrl: './dich-vu-bang-gia.component.html',
  styleUrls: ['./dich-vu-bang-gia.component.css']
})
export class DichVuBangGiaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
