import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DichVuBangGiaPageComponent } from './dich-vu-bang-gia-page.component';

describe('DichVuBangGiaPageComponent', () => {
  let component: DichVuBangGiaPageComponent;
  let fixture: ComponentFixture<DichVuBangGiaPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DichVuBangGiaPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DichVuBangGiaPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
