import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dich-vu-bang-gia-page',
  templateUrl: './dich-vu-bang-gia-page.component.html',
  styleUrls: ['./dich-vu-bang-gia-page.component.css']
})
export class DichVuBangGiaPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
