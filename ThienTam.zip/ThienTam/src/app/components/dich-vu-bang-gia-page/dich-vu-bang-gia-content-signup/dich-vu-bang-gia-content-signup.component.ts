import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dich-vu-bang-gia-content-signup',
  templateUrl: './dich-vu-bang-gia-content-signup.component.html',
  styleUrls: ['./dich-vu-bang-gia-content-signup.component.css']
})
export class DichVuBangGiaContentSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
