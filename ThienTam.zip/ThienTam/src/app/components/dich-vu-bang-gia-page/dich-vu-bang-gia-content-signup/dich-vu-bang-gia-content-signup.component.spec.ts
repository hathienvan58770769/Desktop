import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DichVuBangGiaContentSignupComponent } from './dich-vu-bang-gia-content-signup.component';

describe('DichVuBangGiaContentSignupComponent', () => {
  let component: DichVuBangGiaContentSignupComponent;
  let fixture: ComponentFixture<DichVuBangGiaContentSignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DichVuBangGiaContentSignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DichVuBangGiaContentSignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
