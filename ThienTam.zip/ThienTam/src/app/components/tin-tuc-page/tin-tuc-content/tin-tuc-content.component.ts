import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tin-tuc-content',
  templateUrl: './tin-tuc-content.component.html',
  styleUrls: ['./tin-tuc-content.component.css']
})
export class TinTucContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
