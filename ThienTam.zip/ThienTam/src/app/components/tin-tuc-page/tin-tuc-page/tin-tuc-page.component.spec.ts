import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TinTucPageComponent } from './tin-tuc-page.component';

describe('TinTucPageComponent', () => {
  let component: TinTucPageComponent;
  let fixture: ComponentFixture<TinTucPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TinTucPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TinTucPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
