import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tin-tuc-page',
  templateUrl: './tin-tuc-page.component.html',
  styleUrls: ['./tin-tuc-page.component.css']
})
export class TinTucPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
