import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lien-he',
  templateUrl: './lien-he.component.html',
  styleUrls: ['./lien-he.component.css']
})
export class LienHeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
