import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TrangChuComponent } from './components/trang-chu/trang-chu.component';
import { GioiThieuComponent } from './components/gioi-thieu/gioi-thieu.component';
import { DichVuBangGiaComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia/dich-vu-bang-gia.component';
import { TinTucComponent } from './components/tin-tuc-page/tin-tuc/tin-tuc.component';
import { LienHeComponent } from './components/lien-he/lien-he.component';
import { TinTucContentComponent } from './components/tin-tuc-page/tin-tuc-content/tin-tuc-content.component';
import { TinTucPageComponent } from './components/tin-tuc-page/tin-tuc-page/tin-tuc-page.component';
import { DichVuBangGiaContentSignupComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia-content-signup/dich-vu-bang-gia-content-signup.component';
import { DichVuBangGiaPageComponent } from './components/dich-vu-bang-gia-page/dich-vu-bang-gia-page/dich-vu-bang-gia-page.component';

@NgModule({
  declarations: [
    AppComponent,
    TrangChuComponent,
    GioiThieuComponent,
    DichVuBangGiaComponent,
    TinTucComponent,
    LienHeComponent,
    TinTucContentComponent,
    TinTucPageComponent,
    DichVuBangGiaContentSignupComponent,
    DichVuBangGiaPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
